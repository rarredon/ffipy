__version__ = '0.1.0'
from .ffipy import FFIEC_Client
